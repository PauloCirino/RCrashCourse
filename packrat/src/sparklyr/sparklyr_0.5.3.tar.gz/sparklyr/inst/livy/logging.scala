object Logging {
  def log(message: String) = {
  }

  def logError(message: String) = {
  }

  def logError(message: String, e: Exception) = {
  }

  def logWarning(message: String) = {
  }
}
