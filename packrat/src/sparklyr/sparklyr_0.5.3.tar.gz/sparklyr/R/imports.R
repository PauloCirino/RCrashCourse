#' @import methods
#' @import DBI
#' @import utils
#' @importFrom stats as.formula coefficients gaussian na.fail na.omit predict quantile
NULL

#' @export
dplyr::copy_to
